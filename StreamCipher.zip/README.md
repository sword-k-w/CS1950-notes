# String Cipher

This is a project supported by Jianhao Wong, Jiajun He, Zijian Zhou

Alice will send a message to Bob with Salsa20. The program will check whether what Bob receives is the same as the origin message.